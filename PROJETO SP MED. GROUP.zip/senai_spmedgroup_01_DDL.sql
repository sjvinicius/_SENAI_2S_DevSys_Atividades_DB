CREATE DATABASE spmedgroup
GO

USE spmedgroup
GO

CREATE TABLE tipoUsuario (
	idTipoUsuario 		INT PRIMARY KEY IDENTITY
	,tipo		  	VARCHAR NOT NULL
);
GO

CREATE TABLE especialidade(
	idEspecialidade 	INT PRIMARY KEY IDENTITY
	,area 			VARCHAR NOT NULL
);
GO

CREATE TABLE clinica (
	idClinica		INT PRIMARY KEY IDENTITY
	,nome			VARCHAR NOT NULL
	,cnpj			VARCHAR NOT NULL
	,razaoSocial		VARCHAR NOT NULL
	,endereco		VARCHAR NOT NULL
);
GO


CREATE TABLE paciente (
	idPaciente		INT PRIMARY KEY IDENTITY
	,idConsulta		INT FOREIGN KEY REFERENCES consulta(IdConsulta)
	,nome			VARCHAR(100) NOT NULL
	,dataNasc		DATETIME NOT NULL
	,fone			VARCHAR(10) NOT NULL
	,rg			VARCHAR(9) NOT NULL
	,cpf			VARCHAR(11) NOT NULL
	,endereco		VARCHAR(200) NOT NULL
);
GO

CREATE TABLE usuario (
	idUsuario		INT PRIMARY KEY IDENTITY
	,idPaciente		INT FOREIGN KEY REFERENCES paciente(idPaciente)
	,idMedico		INT FOREIGN KEY REFERENCES medico(idMedico)
	,idTipoUsuario		INT FOREIGN KEY REFERENCES tipoUsuario(idTipoUsuario)
	,email			VARCHAR(50) NOT NULL
	,senha			VARCHAR(25) NOT NULL
);
GO


CREATE TABLE medico (
	idMedico 		INT PRIMARY KEY IDENTITY
	idEspecialidade		INT FOREIGN KEY REFERENCES especialidade(idEspecialidade)
	idClinica		INT FOREIGN KEY REFERENCES clinica(idClinica)
	crm			VARCHAR(8)	NOT NULL
	nome			VARCHAR(100)	NOT NULL
);
GO

CREATE TABLE consulta (
	idConsulta		INT PRIMARY KEY IDENTITY
	,medico			INT FOREIGN KEY REFERENCES medico(idMedico)
	,dataConsult		DATETIME NOT NULL
	,situacao		VARCHAR NOT NULL
);
GO