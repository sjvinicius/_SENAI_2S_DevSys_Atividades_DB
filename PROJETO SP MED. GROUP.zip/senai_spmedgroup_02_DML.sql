INSERT INTO clinica ( nome, cnpj, razaoSocial, endereco )
VALUES	('Clinica Possarle', '86.400.902/0001-30', 'SP Medical GP, Av. Barão Limeira - 532 - São Paulo - SP')
		,('Clinica Lemos', '86.400.902/0002-30', 'SP Medical GP, Av. Barão Limeira, 532 - São Paulo - SP')
		,('Clinica Helena', '86.400.902/0003-30',	'SP Medical GP, Av. Barão Limeira - 532 - São Paulo - SP')
;
GO

INSERT INTO especialidade(area)
VALUES	('Acupuntura')
		,('Anestesiologia') 
		,('Angiologia') 
		,('Cardiologia') 
		,('Cirurgia Cardiovascular')
		,('Cirurgia da Mão')
		,('Cirurgia do Aparelho Digestivo')
		,('Cirurgia Geral')
		,('Cirurgia Pediátrica')
		,('Cirurgia Plástica')
		,('Cirurgia Torácica')
		,('Cirurgia Vascular')
		,('Dermatologia')
		,('Radioterapia')
		,('Urologia')
		,('Pediatria')
		,('Psiquiatria');
GO

INSERT INTO tipoUsuario (tipo)
VALUES  ('administrador')
		,('medico')
		,('paciente');
GO

INSERT INTO consulta (medico, dataconsult, situacao)
VALUES	('Helena Strada',	1/20/20 15:00,	'Realizada')
		,('Roberto Possarle',	01/06/20 10:00,	'Cancelada')
		,('Roberto Possarle',	02/07/20 11:00,	'Realizada')
		,('Roberto Possarle',	02/06/18 10:00,	'Realizada')
		,('Ricardo Lemos',	02/07/19 11:00,	'Cancelada')
		,('Helena Strada',	03/08/20 15:00,	'Agendada')
		,('Ricardo Lemos',	03/09/20 11:00,	'Agendada');
GO

INSERT INTO paciente (idConsulta, nome, dataNasc, fone, rg, cpf, endereco )
VALUES	(1,		'Ligia',		10/13/1983,	'113456-7654',	'43522543-5',		'94839859000',	'Rua Estado de Israel 240 - São Paulo - Estado de São Paulo - 04022-000')
		,(4,	'Alexandre',	7/23/2001,	'1198765-6543',	'32654345-7',		'73556944057',	'Av. Paulista  1578 - Bela Vista - São Paulo - SP - 01310-200')
		,(3,	'Fernando',		10/10/78,	'1197208-4453',	'54636525-3',		'16839338002',	'Av. Ibirapuera - Indianópolis - 2927 -  São Paulo - SP - 04029-200')
		,(5,	'Henrique',		10/13/1985,	'113456-6543',	'54366362-5',		'14332654765',	'R. Vitória - 120 - Vila Sao Jorge = Barueri - SP - 06402-030')
		,(2,	'João',			8/27/1975,	'117656-6377',	't32544444-1',		'91305348010',	'R. Ver. Geraldo de Camargo - 66 - Santa Luzia - Ribeirão Pires - SP - 09405-380')
		,(7,	'Bruno',		3/21/1972,	'1195436-8769',	'54566266-7',		'79799299004',	'Alameda dos Arapanés = 945 - Indianópolis - São Paulo - SP - 04524-001')
		,(6,	'Mariana',		03/05/18,	NULL,			'54566266-8',		'13771913039',	'R Sao Antonio - 232 - Vila Universal - Barueri - SP - 06407-140');
GO

INSERT INTO medico (idConsulta, idEspecialidade, idClinica, nome, crm)
VALUES		(7,		2,	2,	'Ricardo Lemos',		'54356-SP')
			,(3,	17,	1,	'Roberto Possarle',		'53452-SP')
			,(6,	16,	3,	'Helena Strada',		'65463-SP');
GO

INSERT INTO usuario (idPaciente, idMedico, idTipoUsuario, email, senha)
VALUES		 (1,	NULL,	3,	'ligia@gmail.com',							'123')
			,(2,	NULL,	3,	'alexandre@gmail.com',						'321')
			,(3,	NULL,	3,	'fernando@gmail.com',						'213')
			,(4,	NULL,	3,	'henrique@gmail.com',						'231')
			,(5,	NULL,	3,	'joao@hotmail.com',							'313')
			,(6,	NULL,	3,	'bruno@gmail.com',							'123')
			,(7,	NULL,	3,	'mariana@outlook.com',						'312')
			,(NULL,	1,		2,	'ricardo.lemos@spmedicalgroup.com.br',		'231')
			,(NULL,	2,		2,	'roberto.possarle@spmedicalgroup.com.br',	'123')
			,(NULL,	3,		2,	'helena.souza@spmedicalgroup.com.br',		'231');
GO

