SELECT nome
FROM especialidade;
GO

SELECT crm, nome, Email, especialidade.nome, clinica.nome, clinica.cnpj, clinica.razaoSocial, clinica.endereco
FROM medicos
INNER JOIN especialidade
ON medico.idEspecialidade = especialidade.idEspecialidade
&&
INNER JOIN clinica
ON medico.idClinica = clinica.idClinica;
GO


SELECT nome, consulta.idMedico, consulta.dataConsult, consulta.situacao
FROM	paciente
INNER JOIN consulta
ON paciente.idConsulta = consulta.idConsulta;
GO

SELECT nome, email, dataNasc, fone, rg, cpf, endereco
FROM paciente
INNER JOIN usuario
ON paciente.email = usuario.email;
GO 





